TgWitness external timestamp preparation

No external service has been contacted. This archive is NOT a trusted timestamp.
checkpoint.json is signed by the collector; timestamp.tsq is an RFC 3161 request
for SHA-256 of the exact checkpoint.json bytes, with a random nonce.

Send timestamp.tsq to a TSA you independently trust using its documented method.
Retain the original request, checkpoint, and returned timestamp.tsr.
Obtain the TSA CA certificate chain independently, not solely from the response.

Verify from a trusted TgWitness installation:
python -m tgwitness.anchor verify --checkpoint checkpoint.json --request timestamp.tsq --response timestamp.tsr --ca trusted-tsa-root.pem

If needed add --intermediates tsa-intermediates.pem and --openssl /path/to/openssl.
The verifier checks both checkpoint bytes and the original request (including nonce).
Then verify the evidence ZIP against checkpoint.json and a separately trusted
collector fingerprint using tgwitness/verify.py.

A TSA response establishes a statement about existence of these bytes at the TSA's
time. It does not authenticate Telegram origin or make every claim in the bytes true.
