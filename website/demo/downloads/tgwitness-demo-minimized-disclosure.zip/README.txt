Minimized disclosure

This is a minimized derivative, not the complete original account export.
Pseudonymization is not anonymization. Dates, context and message content can still identify people.
Automatic text masking cannot find every personal detail. Review the disclosed content before sharing.
A signature protects this derivative. Source linkage alone does not prove that filtering or redaction was correct.
Purpose and settings do not establish a legal basis, GDPR compliance or court admissibility.

The original source, identity map and private selection criteria are NOT included.
Verify from an independently trusted installation:
python verify.py disclosure.zip --fingerprint TRUSTED_SHA256
Optional --evidence original.zip checks source linkage, not the correctness of redaction.
For large packages add --max-gib with the expanded size. index.html is protected by the manifest.
