TgWitness · Evidence archive

================================================================
Created: 2026-11-05 19:20:21 UTC
Report ID: ab558b9f-e45e-4bf0-a614-6612522200b7
Signing key fingerprint: c0de23aa500f303b7aaadcc0f5938451ca17c9290368ed37f41c630405a36abc

Start here
----------------------------------------------------------------
Extract the complete archive before opening the HTML report. Keep viewer/ and media/ beside it.
  report.html — Report, search, filters and archive verification
Keep the original ZIP unchanged. Save selections and working notes outside the extracted folder.

What is in this archive
----------------------------------------------------------------
  README.txt             Instructions in the report language and in English
  SHA256SUMS             SHA-256 checksums of the listed payload files, for sha256sum -c
  analytics.json         
  coverage.json          Observation periods, gaps and message IDs never observed
  custody.json           Chain of custody and acquisition details
  events.csv             The same records for spreadsheets (formula-safe)
  events.jsonl           Authoritative journal: one signed record per line
  indicators.csv         Indicators for spreadsheets: links, domains, wallets, accounts (formula-safe)
  indicators.misp.json   The same indicators as a MISP event
  indicators.stix.json   The same indicators as a STIX 2.1 bundle
  manifest.json          Signed list of every file with its SHA-256
  manifest.sig           Ed25519 signature of manifest.json
  report.html            This readable report, sealed
  report.json            The report as signed JSON, for case systems and scripts
  verify.py              Standalone verifier (Python 3.11+, cryptography)
  media/                 Saved file, named by its SHA-256 (1)
  viewer/                Viewer data: checked against the report seal before display (2)

How to verify
----------------------------------------------------------------
Run these commands in the extracted folder, with the original ZIP in its parent folder.
Use a verifier from a trusted checkout. The bundled copy is provided for convenience.
1. Get the signer's key fingerprint from a trusted channel, not from this archive.
   python verify.py ../tgwitness-evidence.zip --fingerprint TRUSTED_SHA256
2. Without Python, check the file hashes (not the signature):
   sha256sum -c SHA256SUMS            (macOS: shasum -a 256 -c SHA256SUMS)
   Get-FileHash -Algorithm SHA256 <file>   (Windows PowerShell)
3. Timestamps: check an RFC 3161 answer with OpenSSL and the authority's root certificate:
   openssl ts -verify -data anchors/<checkpoint>.json -in anchors/<checkpoint>.<service>.tsr -CAfile tsa-root.pem
   OpenTimestamps proofs: ots upgrade, then ots verify -f CHECKPOINT.json PROOF.ots
4. The report alone: python verify.py report.html --fingerprint TRUSTED_SHA256 --evidence ../tgwitness-evidence.zip

Checksum scope
----------------------------------------------------------------
SHA256SUMS covers the payload files listed inside it. It excludes itself, manifest.json and manifest.sig.
The signed manifest also covers SHA256SUMS. manifest.sig authenticates the exact bytes of manifest.json.
Matching hashes establish file integrity; they do not establish the identity of the signer or the truth of the messages.

Working with the data
----------------------------------------------------------------
JSON and JSONL are UTF-8. Times are ISO 8601 in UTC; numeric Telegram IDs identify accounts and chats, not people.
Import CSV as UTF-8 and keep ID, wallet and hash columns as text. Formula-like values are escaped for spreadsheets.
Indicators are observations, not verdicts. Review their source references before importing STIX or MISP.
The PDF is a signed reading copy. Use the HTML viewer for search and the JSON or JSONL for structured analysis.

Limitations
----------------------------------------------------------------
- This journal records observations made by a Telegram client, not Telegram-signed evidence.
- Observed time uses the collector's system clock; it is not a trusted timestamp.
- Messages deleted before collection and unobserved intermediate edits cannot be recovered.
- Deletion actors are generally unavailable. Unscoped deletions are not attributed to a chat.
- Reaction identities and membership changes are partial and depend on Telegram visibility.
- Backfill is a current history snapshot, not reconstruction of missed events.
- Signatures detect changes relative to a trusted key. Retain the fingerprint and checkpoints elsewhere.

Additional verification options
Require a witnessed export boundary: add --witness witness.zip
  --witness-fingerprint TRUSTED_WITNESS_SHA256 --require-witness
The witness must have retained the exact exported head. This verifies consistency
with its retained records, not the truth of the recorded messages.
Archives above 4 GiB uncompressed also need --max-gib with their size in GiB.
Requires Python 3.11+ and cryptography. CSV cells are formula-escaped.
events.jsonl is authoritative. Export is a stable journal prefix.
coverage.json lists continuous observation periods, gaps and message IDs that were
never observed (not evidence of deletion); verify.py recomputes it from events.jsonl.
Produced by TgWitness (PhishDestroy, https://phishdestroy.io); the producer is part of
the signed manifest.

