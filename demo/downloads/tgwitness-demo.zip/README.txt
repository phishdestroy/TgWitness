TgWitness · Evidence archive
Harbor portal · Fictional investigation
================================================================
Case ID: HBR-042
Created: 2026-11-01 15:53:13 UTC
Report ID: 3f5094c1-8c5a-4cd5-b2a0-798d2b52846c
Signing key fingerprint: eca5654f58bffbbeed443ff65f4c903b8660c1d2a02f0b94d6e6c33bddcd3ea2

What is in this archive
----------------------------------------------------------------
  README.txt      Instructions in the report language and in English
  SHA256SUMS      SHA-256 of every file, for sha256sum -c
  coverage.json   Observation periods, gaps and message IDs never observed
  custody.json    Chain of custody and acquisition details
  events.csv      The same records for spreadsheets (formula-safe)
  events.jsonl    Authoritative journal: one signed record per line
  manifest.json   Signed list of every file with its SHA-256
  manifest.sig    Ed25519 signature of manifest.json
  report.html     This readable report, sealed
  verify.py       Standalone verifier (Python 3.11+, cryptography)

How to verify
----------------------------------------------------------------
1. Get the signer's key fingerprint from a trusted channel, not from this archive.
   python verify.py tgwitness-evidence.zip --fingerprint eca5654f58bffbbeed443ff65f4c903b8660c1d2a02f0b94d6e6c33bddcd3ea2
2. Without Python, check the file hashes (not the signature):
   sha256sum -c SHA256SUMS            (macOS: shasum -a 256 -c SHA256SUMS)
   Get-FileHash -Algorithm SHA256 <file>   (Windows PowerShell)
3. Timestamps: check an RFC 3161 answer with OpenSSL and the authority's root certificate:
   openssl ts -verify -data anchors/<checkpoint>.json -in anchors/<checkpoint>.<service>.tsr -CAfile tsa-root.pem
   OpenTimestamps proofs: ots upgrade, then ots verify -f CHECKPOINT.json PROOF.ots
4. The report alone: python verify.py report.html --fingerprint eca5654f58bffbbeed443ff65f4c903b8660c1d2a02f0b94d6e6c33bddcd3ea2 --evidence tgwitness-evidence.zip

Limitations
----------------------------------------------------------------
- This journal records observations made by a Telegram client, not Telegram-signed evidence.
- Observed time uses the collector's system clock; it is not a trusted timestamp.
- Messages deleted before collection and unobserved intermediate edits cannot be recovered.
- Deletion actors are generally unavailable. Unscoped deletions are not attributed to a chat.
- Reaction identities and membership changes are partial and depend on Telegram visibility.
- Backfill is a current history snapshot, not reconstruction of missed events.
- Signatures detect changes relative to a trusted key. Retain the fingerprint and checkpoints elsewhere.
This journal records observations made by a Telegram client, not Telegram-signed evidence.
Observed time uses the collector's system clock; it is not a trusted timestamp.
Messages deleted before collection and unobserved intermediate edits cannot be recovered.
Deletion actors are generally unavailable. Unscoped deletions are not attributed to a chat.
Reaction identities and membership changes are partial and depend on Telegram visibility.
Backfill is a current history snapshot, not reconstruction of missed events.
Signatures detect changes relative to a trusted key. Retain the fingerprint and checkpoints elsewhere.

Use a verifier from a trusted checkout, not solely from an untrusted ZIP.
Verify: python verify.py evidence.zip --fingerprint TRUSTED_SHA256
Require a witnessed export boundary: add --witness witness.zip
  --witness-fingerprint TRUSTED_WITNESS_SHA256 --require-witness
The witness must have retained the exact exported head. This verifies consistency
with its retained records, not the truth of the recorded messages.
Archives above 4 GiB uncompressed also need --max-gib with their size in GiB.
Requires Python 3.11+ and cryptography. CSV cells are formula-escaped.
events.jsonl is authoritative. Export is a stable journal prefix.
coverage.json lists continuous observation periods, gaps and message IDs that were
never observed (not evidence of deletion); verify.py recomputes it from events.jsonl.
report.html is a readable derivative sealed with the same key; custody.json records how
the material was acquired and exported; SHA256SUMS repeats the manifest for sha256sum -c.
Produced by TgWitness (PhishDestroy, https://phishdestroy.io); the producer is part of
the signed manifest.
