TgWitness account export

A snapshot of data visible to this account during the recorded acquisition intervals; not Telegram-signed evidence.
Deleted data, inaccessible history, previous edits and secret chats may be unavailable.
Capture times are the collector's clock, not an independent timestamp. Pin the signing fingerprint independently.
Options and inventory are frozen. Resume retains earlier observations; it does not make an atomic account snapshot.
Media exclusions and acquisition failures are recorded. A valid signature does not establish completeness.

Verify using verify.py from a trusted checkout, with --fingerprint TRUSTED_SHA256.
data/*.jsonl are authoritative; receipts bind each page to frozen options and inventory.
HTML is a readable derivative. Media names are content hashes.
